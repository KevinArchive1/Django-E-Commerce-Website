from django.contrib import admin
from .models import Shoes

# Register your models here.

admin.site.register(Shoes)

